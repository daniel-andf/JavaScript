function countBs (a){ //remember to add comentaries

	var count = 0;
	
	for (i=0;i < a.length;i++)
	{
		if (a.charAt(i) == "B")
			count++;
	}

	return count;
}

function countChar (a,b){ //remember to add comentaries

	var count = 0;
	
	for (i=0;i < a.length;i++)
	{
		if (a.charAt(i) == b)
			count++;
	}

	return count;
}


console.log(countBs("BBC"));

console.log(countChar("kakkerlak", "k"));


