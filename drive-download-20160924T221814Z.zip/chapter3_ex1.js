function min (a,b){ //remember to add comentaries

	if (a < b)
	{
		return a;
	}
	else
	{
		return b;
	}

}

console.log (min(0,10));

console.log  (min(0,-10));